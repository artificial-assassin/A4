#include "startup_code.cpp"
#include <iomanip>

#ifndef PRINTS_CPP
	#define PRINTS_CPP

void print_missing(vector<vector<double> >& missing)
{
	cout << "----------MISSING VALUE DISTRIBUTION------------\n";
	for (int i = 0 ; i<missing.size() ; i++)
	{
		for (int j = 0 ; j<missing[i].size() ; j++)
			cout << missing[i][j] << " ";
		cout << "\n";
	}
	
	cout << "\n";
}

void print_CPT(vector<vector<double> >& CPT)
{
	cout << "----------------------CPT------------------------\n";
	for (int i = 0 ; i<CPT.size() ; i++)
	{
		for (int j = 0 ; j<CPT[i].size() ; j++)
			cout << CPT[i][j] << " ";
		cout << "\n";
	}
	cout << "\n\n";
}

void print_network(string inputFile, string outputFile, network& solvedAlarm)
{
	network Alarm;
	string line;
	int find=0;
  	ifstream myfile(inputFile);
	ofstream fout(outputFile);
  	string temp;
  	string name;
	int node_number = 0;
  	int pnode_number = 0;
    if (myfile.is_open())
    {
    	while (! myfile.eof() )
    	{
    		stringstream ss;
      		getline (myfile,line);
      		
      		
      		ss.str(line);
			if(myfile.eof())
				fout<< line;
			else
				fout << line << "\n";
     		ss>>temp;
     		
     		if(temp.compare("variable")==0)
     		{
     				getline (myfile,line);
                   	fout << line << "\n";
					node_number++;
     		}
     		else if(temp.compare("probability")==0)
     		{
					vector<double> CPT = solvedAlarm.get_nth_node(pnode_number).get_CPT();
					fout << "\ttable ";
					for(vector<double>::iterator it = CPT.begin(); it != CPT.end(); it++)
					{
						//fout << *it << " ";
						fout << fixed << setprecision(4) << *it << " ";
					}
					fout << ";\n";
    				getline (myfile,line);
					pnode_number++;
     		}
    	}
  	}  	
	myfile.close();
	fout.close();
}

#endif