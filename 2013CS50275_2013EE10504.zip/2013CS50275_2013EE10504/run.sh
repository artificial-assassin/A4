#! /bin/bash
./run $1 $2 solved_$1